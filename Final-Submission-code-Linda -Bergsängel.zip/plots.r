plot(mtcars$mpg,mtcars$hp)

plot(mtcars$mpg,mtcars$hp,
  main = "Relationship between Miles per Gallon and Horsepower",
  xlab = "Miles per Gallon",
  ylab = "Horsepower")

plot(mtcars$mpg,mtcars$hp, type = "h",
  main = "Relationship between Miles per Gallon and Horsepower",
  xlab = "Miles per Gallon",
  ylab = "Horsepower")

  
  